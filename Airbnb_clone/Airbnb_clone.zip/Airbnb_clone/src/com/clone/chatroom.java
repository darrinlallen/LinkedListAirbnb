package com.clone;
import java.util.Objects;
import java.lang.*;
public class chatroom {
    protected String name;
    protected String users;
    @Override
    public boolean equals(Object o){
        if (o == this) {return true;}
        if (!( o instanceof chatroom)){
            return false;
        }
        chatroom chat = (chatroom) o;
        return name == chat.name && Objects.equals(name, chat.name)
                && Objects.equals(users, chat.users);

    }
    public chatroom(String name, String users) {
        this.name = name;
        this.users = users;


    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUsers() {
        return users;
    }

    public void setUsers(String users) {
        this.users = users;
    }
}
