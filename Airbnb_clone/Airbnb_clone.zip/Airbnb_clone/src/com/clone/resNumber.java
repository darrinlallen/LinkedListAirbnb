package com.clone;

public abstract class resNumber {

public abstract void clientNum();
}
