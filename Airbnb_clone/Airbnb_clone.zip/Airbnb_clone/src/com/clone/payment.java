package com.clone;
public class payment {

    private String user;
    private String listing;
    private float amount;

    public payment(String user, String listing, float amount) {
        this.user = user;
        this.listing = listing;
        this.amount = amount;

    }

    public void setUser(String user) {
        this.user = user;
    }

    public void setListing(String listing) {
        this.listing = listing;
    }

    public void setAmount(float amount) {
        this.amount = amount;
    }

    public String getUser() {
        return user;
    }

    public String getListing() {
        return listing;
    }

    public float getAmount() {
        return amount;
    }
}