package com.clone;
public class booking {
    private String user;
    private String listing;
    private String start;
    private String end;


    public booking(String user, String listing, String start, String end) {

        this.user = user;
        this.listing = listing;
        this.start = start;
        this.end = end;
    }
    public int reservationNumber(){
        return 999;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getListing() {
        return listing;
    }

    public void setListing(String listing) {
        this.listing = listing;
    }

    public String getStart() {
        return start;
    }

    public void setStart(String start) {
        this.start = start;
    }

    public String getEnd() {
        return end;
    }

    public void setEnd(String end) {
        this.end = end;
    }
}
