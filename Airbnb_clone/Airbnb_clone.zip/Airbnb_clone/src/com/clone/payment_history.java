package com.clone;
public class payment_history {
    private String user;
    private int amount;

    public payment_history(String user, int amount) {
        this.user = user;
        this.amount = amount;
    }

    public String getuser() {
        return user;
    }

    public void setuser(String user) {
        this.user = user;
    }

    public int getamount() {
        return amount;
    }

    public void setamount(int amount) {
        this.amount = amount;
    }
}
