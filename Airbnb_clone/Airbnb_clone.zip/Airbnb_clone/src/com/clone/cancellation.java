package com.clone;

public class cancellation {
    protected String user;
    protected String reason;

    public cancellation(String user, String reason) {

        this.user = user;
        this.reason = reason;
    }
    @Override
public String toString (){
    return "name  " + user + "    reason  "+ reason;
}

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }
}
