package com.clone;
public class message_history {
    public String user;
    public String messages;

    public message_history(String user, String messages) {
        this.user = user;
        this.messages = messages;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getMessages() {
        return messages;
    }

    public void setMessages(String messages) {
        this.messages = messages;
    }
}
