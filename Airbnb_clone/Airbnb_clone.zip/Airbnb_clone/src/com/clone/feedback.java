package com.clone;
public class feedback {
    protected String feedback_loop;

    public feedback(String feedback_loop) {
        this.feedback_loop = feedback_loop;
    }

    public String getFeedback_loop() {
        return feedback_loop;
    }

    public void setFeedback_loop(String feedback_loop) {
        this.feedback_loop = feedback_loop;
    }
}
