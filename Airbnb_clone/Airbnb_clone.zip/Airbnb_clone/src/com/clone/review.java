package com.clone;
public class review {

    private String user;
    private String listing;
    private String rating;

    public String getUser() {
        return user;
    }

    public String getListing() {
        return listing;
    }

    public String getRating() {
        return rating;
    }

    public String getReview() {
        return review;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public void setListing(String listing) {
        this.listing = listing;
    }

    public void setRating(String rating) {
        this.rating = rating;
    }

    public void setReview(String review) {
        this.review = review;
    }

    private String review;

    public review(String user, String listing, String rating, String review) {
        this.user = user;
        this.listing = listing;
        this.rating = rating;
        this.review = review;
    }

}