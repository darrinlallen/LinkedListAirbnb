package com.clone;
public class reservation {

    private String user;
    private String listing;
    private String start;
    private String end;

    public reservation(String user, String listing, String start, String end) {
        this.user = user;
        this.listing = listing;
        this.start = start;
        this.end = end;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public void setListing(String listing) {
        this.listing = listing;
    }

    public void setStart(String start) {
        this.start = start;
    }

    public void setEnd(String end) {
        this.end = end;
    }

    public String getUser() {
        return user;
    }

    public String getListing() {
        return listing;
    }

    public String getStart() {
        return start;
    }

    public String getEnd() {
        return end;
    }
}
