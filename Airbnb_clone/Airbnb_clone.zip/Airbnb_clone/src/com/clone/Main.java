// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
package com.clone;
import com.clone.cancellation;

import java.util.Objects;


public class Main {
    public static void main(String[] args) {
        // Press Alt+Enter with your caret at the highlighted text to see how
        // IntelliJ IDEA suggests fixing it.
        User Darrin = new User("darrin", "darrin.allen@gmail.com", "passw0rd");
        System.out.println(Darrin.name);

        cancellation lilly = new cancellation("lilly", "novacation");
        System.out.println(lilly);

        chatroom john = new chatroom("john", "xyz");
        chatroom sam = new chatroom("johnny", "xyz");
        System.out.println(john.equals(sam));

        message test = new message("darrin", "lucy", "hello");
        System.out.println(Objects.hashCode(test));
    }
}