package com.clone;
public class notification extends notification_history{
    public String message;

    public notification(String user, String message, String status) {
        super(user, status);
         message = message;
    }

    @Override
    public void setStatus(String status) {
        this.status = status;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(int status) {
        status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        message = message;
    }
}
